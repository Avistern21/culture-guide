# Our Culture Guide

A private-feeling culture guide for dance, music, museums, galleries, Broadway, restaurants and reads.
It updates itself every night: a small job visits each venue's website, saves the official preview image,
and picks up any events the venue publishes in a machine-readable form. No server and no cost.

## Put it online (about 10 minutes, one time)

1. Make a free account at github.com if you don't have one.
2. Click **+ > New repository**. Name it `culture-guide`, choose **Public** (free Pages needs this on a free account), click **Create repository**.
3. On the new repo page click **uploading an existing file**. Unzip this project, drag **everything inside the folder** in (including the hidden `.github` folder, so turn on "show hidden files" on your computer first), then click **Commit changes**.
   Check that `.github/workflows/update.yml` shows up in the repo. If it doesn't, click **Add file > Create new file**, type `.github/workflows/update.yml`, and paste in the file's text.
4. Go to **Settings > Pages**. Under **Build and deployment > Source**, choose **GitHub Actions**.
5. Go to **Settings > Actions > General > Workflow permissions**, choose **Read and write permissions**, and click Save.
6. Go to the **Actions** tab, click **Update and publish** on the left, then **Run workflow**. Wait a few minutes.
7. Your site is at `https://YOUR-USERNAME.github.io/culture-guide/`. After this it refreshes by itself every night.

Public repo means anyone with the link could find the site. It only contains venue names and public show listings, but don't put anything private in it.

## What updates by itself

- **Venue images:** each venue's official preview image (the one used when its link is shared).
- **Shows:** any event a venue publishes as schema.org structured data on its page (many museums and theaters do; some don't).
- **Cleanup:** ended shows disappear from the site on their own.

## What you edit by hand

All of these are plain text files you can edit right on GitHub (open the file, click the pencil, then Commit).

- `data/shows.json`: shows I added for you. Add a line like
  `{"venue": "the-joyce-theater", "title": "Show name", "start": "2026-12-01", "end": "2026-12-12", "url": "https://..."}`
  The `venue` is the id from `data/venues.json`. If you give a `url` that is a specific show page, the nightly job fetches that page's image for the card.
- `data/venues.json`: add or remove venues. Fields: `id`, `cat` (dance, music, museums, galleries), `name`, `area`, `url`, `note`.
  Optional: `eventsUrl` (a calendar page to read events from) and `imageUrl` (force a particular image).
- `data/picks.json`: shared picks for Broadway, restaurants, reads and discover:
  `{"cat": "restaurants", "name": "Name", "area": "West Village", "url": "https://resy.com/...", "note": "Why we love it"}`
- `img/manual/<venue-id>.jpg`: upload your own image for any venue and it always wins over the automatic one.

## If a venue has no image or no shows

Open `data/update-log.json` after a run. It lists which venues failed and why. Some sites block automated visits.
For those, add an image to `img/manual/` and add their shows to `data/shows.json`.

## Notes

- Calendar entries and picks you add with the forms on the site are saved only in that browser. To share something with your wife, put it in the data files above.
- Check each venue before buying tickets. Dates come from venue pages and news listings.
- Preview locally: `npm install`, `npm run update`, `npm run serve`, then open http://localhost:8000
